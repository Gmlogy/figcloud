// src/components/PhoneVerificationModal.jsx
import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Smartphone, Lock, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import "../../aws-amplify-config";

import {
  signIn,
  confirmSignIn,
  fetchAuthSession,
  getCurrentUser,
} from "aws-amplify/auth";

export default function PhoneVerificationModal({ onVerificationComplete }) {
  const [step, setStep] = useState("phone"); // "phone" | "otp"
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");

  // mode: 0 none, 1 = confirmSignIn (login OTP)
  const [mode, setMode] = useState(0);

  useEffect(() => {
    (async () => {
      try {
        await getCurrentUser();
        onVerificationComplete("");
      } catch {}
    })();
  }, [onVerificationComplete]);

  const formatPhoneInput = (value) => {
    if (!value) return "";
    let v = value.replace(/[^\d+]/g, "");
    return v[0] === "+" ? "+" + v.slice(1).replace(/\+/g, "") : v.replace(/\+/g, "");
  };

  // Normalize -> E.164; keep "+..." as-is. Tweak default if you want.
  const toE164 = (input) => {
    const v = (input || "").trim();
    if (v.startsWith("+")) return v.replace(/\s+/g, "");
    const digits = v.replace(/\D/g, "");
    // Example fallback (+1). Adjust for your audience if desired.
    if (digits.length >= 6) return `+1${digits}`;
    return v;
  };

  const startSigninThenSelectSms = async (e164) => {
    // Start choice-based sign-in
    const out = await signIn({ username: e164, options: { authFlowType: "USER_AUTH" } });

    // If already signed in (rare), we’re done.
    const session = await fetchAuthSession();
    if (session?.tokens) return { done: true };

    const step = out?.nextStep?.signInStep || "";
    const challenge = out?.nextStep?.challengeName || "";

    // New “choice” step → pick SMS_OTP
    if (step === "CONTINUE_SIGN_IN_WITH_FIRST_FACTOR_SELECTION") {
      await confirmSignIn({ challengeResponse: "SMS_OTP" });
      return { done: false, selectedSms: true };
    }

    // Some SDKs surface the explicit challenge name
    if (challenge === "SMS_OTP") {
      return { done: false, selectedSms: true };
    }

    // Older/alternate step name that already means “enter the SMS code”
    if (String(step).includes("SMS")) {
      return { done: false, selectedSms: true };
    }

    // WebAuthn/password/etc. not supported in this UI
    throw new Error(`Unsupported next step: ${step || challenge}`);
  };

  const handlePhoneSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");
    setInfo("");

    const e164 = toE164(phoneNumber);

    try {
      if (!e164.startsWith("+")) {
        setError("Please enter a valid E.164 phone (e.g., +2126...)");
        setIsLoading(false);
        return;
      }

      const res = await startSigninThenSelectSms(e164);
      setIsLoading(false);

      if (res.done) {
        onVerificationComplete(e164);
        return;
      }

      // Expecting SMS OTP now
      setMode(1);
      setStep("otp");
      setInfo("We sent you a sign-in code by SMS.");
    } catch (err) {
      setIsLoading(false);
      const name = err?.name || err?.__type || "";

      if (name.includes("UserNotFound")) {
        setError("No account found for this phone number. Please create your account from the mobile app first.");
      } else if (name.includes("UserNotConfirmed")) {
        setError("This account isn’t confirmed. Please complete setup from the mobile app.");
      } else if (name.includes("NotAuthorized")) {
        setError("Sign-in failed. Make sure this phone number matches an existing account.");
      } else {
        setError(err?.message || "Failed to start sign-in.");
      }
    }
  };

  const handleOtpSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");
    setInfo("");

    try {
      const e164 = toE164(phoneNumber);
      if (otpCode.length < 4) {
        setError("Enter the code you received");
        setIsLoading(false);
        return;
      }

      // Confirm the SMS code (Amplify tracks the current challenge)
      await confirmSignIn({ challengeResponse: otpCode });

      const session = await fetchAuthSession();
      setIsLoading(false);
      if (session?.tokens) onVerificationComplete(e164);
      else setError("Could not complete sign-in. Resend and try again.");
    } catch (e4) {
      setIsLoading(false);
      setError(e4?.message || "Invalid/expired code.");
    }
  };

  const handleResend = async () => {
    setIsLoading(true);
    setError("");
    setInfo("");
    const e164 = toE164(phoneNumber);
    try {
      const res = await startSigninThenSelectSms(e164);
      if (res.done) {
        onVerificationComplete(e164);
        return;
      }
      setInfo("Code re-sent.");
    } catch (e) {
      setError(e?.message || "Unable to resend code.");
    }
    setIsLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-md">
        <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-0">
          <CardHeader className="text-center pb-6">
            <div className="w-16 h-16 mx-auto mb-4 bg-[#E4E1F7] rounded-full flex items-center justify-center">
              <Shield className="w-8 h-8" style={{ color: "#20194B" }} />
            </div>
            <CardTitle className="text-2xl font-bold text-slate-900">
              {step === "phone" ? "Verify Your Phone" : "Enter Verification Code"}
            </CardTitle>
            <p className="text-slate-600 mt-2">
              {step === "phone"
                ? "Enter your phone number to sign in"
                : `We sent a code to ${phoneNumber}`}
            </p>
          </CardHeader>

          <CardContent>
            {step === "phone" ? (
              <form onSubmit={handlePhoneSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="phone" className="text-sm font-medium text-slate-700">
                    Phone Number
                  </Label>
                  <div className="relative mt-1">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                      <Smartphone className="h-5 w-5 text-slate-400" />
                    </div>
                    <Input
                      id="phone"
                      type="tel"
                      inputMode="tel"
                      placeholder="(e.g. +2126..., +1415...)"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(formatPhoneInput(e.target.value))}
                      className="pl-12 h-12 text-lg"
                      maxLength={18}
                      required
                      pattern="^\+?[0-9]{6,15}$"
                    />
                  </div>
                </div>

                {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-lg">{error}</p>}
                {info && <p className="text-sm text-green-700 bg-green-50 p-3 rounded-lg">{info}</p>}

                <Button type="submit" className="w-full h-12" style={{ backgroundColor: "#20194B" }} disabled={isLoading}>
                  {isLoading ? "Sending Code..." : (
                    <>
                      Send Verification Code <ArrowRight className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>

                <div className="flex items-center gap-2 text-xs text-slate-500 mt-4">
                  <Lock className="w-4 h-4" />
                  <span>Your phone number is encrypted and never shared</span>
                </div>
              </form>
            ) : (
              <form onSubmit={handleOtpSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="otp" className="text-sm font-medium text-slate-700">
                    Verification Code
                  </Label>
                  <Input
                    id="otp"
                    type="text"
                    placeholder="123456 or 12345678"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, "").slice(0, 8))}
                    className="text-center text-2xl font-mono tracking-widest h-12"
                    maxLength={8} // accept 6–8 digits
                    required
                  />
                </div>

                {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-lg">{error}</p>}
                {info && <p className="text-sm text-green-700 bg-green-50 p-3 rounded-lg">{info}</p>}

                <Button
                  type="submit"
                  className="w-full h-12"
                  style={{ backgroundColor: "#20194B" }}
                  disabled={isLoading || otpCode.length < 4}
                >
                  {isLoading ? "Verifying..." : "Verify & Sign in"}
                </Button>

                <div className="flex items-center justify-between">
                  <Button
                    type="button"
                    variant="ghost"
                    className="mt-2"
                    onClick={() => { setStep("phone"); setOtpCode(""); setInfo(""); setError(""); }}
                    disabled={isLoading}
                  >
                    ← Change Phone Number
                  </Button>
                  <Button type="button" variant="ghost" className="mt-2" onClick={handleResend} disabled={isLoading}>
                    Resend code
                  </Button>
                </div>
              </form>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
