// src/index.jsx (or the file you showed)
import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';
import { getCurrentUser, signOut as amplifySignOut } from "aws-amplify/auth";
import "../aws-amplify-config";

import Layout from "./Layout.jsx";
import Dashboard from "./Dashboard";
import SyncStatus from "./SyncStatus";
import Settings from "./Settings";
import Photos from "./Photos";
import Contacts from "./Contacts";
import ReverseSync from "./ReverseSync";
import PhoneVerificationModal from "../components/auth/PhoneVerificationModal";

const PAGES = {
  Dashboard,
  SyncStatus,
  Settings,
  Photos,
  Contacts,
  ReverseSync,
};

function _getCurrentPage(url) {
  if (url.endsWith('/')) url = url.slice(0, -1);
  let urlLastPart = url.split('/').pop();
  if (urlLastPart.includes('?')) urlLastPart = urlLastPart.split('?')[0];
  const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
  return pageName || Object.keys(PAGES)[0];
}

function AuthGate({ children }) {
  const [authed, setAuthed] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    (async () => {
      try { await getCurrentUser(); setAuthed(true); } 
      catch { setAuthed(false); }
      finally { setChecking(false); }
    })();
  }, []);

  if (checking) return null; // or a spinner

  return (
    <>
      {!authed && (
        <PhoneVerificationModal
          onVerificationComplete={() => setAuthed(true)}
        />
      )}
      {authed && children}
    </>
  );
}

// Accept signOut as a prop
function PagesContent({ signOut }) {
  const location = useLocation();
  const currentPage = _getCurrentPage(location.pathname);

  return (
    <Layout currentPageName={currentPage} signOut={signOut}>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/Dashboard" element={<Dashboard />} />
        <Route path="/SyncStatus" element={<SyncStatus />} />
        <Route path="/Settings" element={<Settings />} />
        <Route path="/Photos" element={<Photos />} />
        <Route path="/Contacts" element={<Contacts />} />
        <Route path="/ReverseSync" element={<ReverseSync />} />
      </Routes>
    </Layout>
  );
}

// Accept signOut as a prop
export default function Pages({ signOut }) {
  // If you want your Layout’s “Sign out” to use Amplify:
  const doSignOut = async () => {
    try { await amplifySignOut(); }
    finally { window.location.href = "/"; }
  };

  return (
    <Router>
      <AuthGate>
        <PagesContent signOut={doSignOut} />
      </AuthGate>
    </Router>
  );
}
