// src/components/PhoneVerificationModal.jsx
import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Smartphone, Lock, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import "../../aws-amplify-config";

import {
  signIn,
  confirmSignIn,
  signUp,
  confirmSignUp,
  resendSignUpCode,
  fetchAuthSession,
  getCurrentUser,
} from "aws-amplify/auth";

export default function PhoneVerificationModal({ onVerificationComplete }) {
  const [step, setStep] = useState("phone");   // "phone" | "otp"
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");

  // mode: 0 none, 1 = confirmSignIn (login OTP), 2 = confirmSignUp (registration OTP)
  const [mode, setMode] = useState(0);
  const [tmpPwd, setTmpPwd] = useState("");

  useEffect(() => {
    (async () => {
      try { await getCurrentUser(); onVerificationComplete(""); } catch {}
    })();
  }, [onVerificationComplete]);

  // Allow a single leading "+"; rest must be digits
  const formatPhoneInput = (value) => {
    if (!value) return "";
    let v = value.replace(/[^\d+]/g, "");
    return v[0] === "+"
      ? "+" + v.slice(1).replace(/\+/g, "")
      : v.replace(/\+/g, "");
  };

  // Normalize -> E.164; keep "+..." as-is. Provide US fallback; customize if needed.
  const toE164 = (input) => {
    const v = (input || "").trim();
    if (v.startsWith("+")) return v.replace(/\s+/g, "");
    const digits = v.replace(/\D/g, "");
    // Example Morocco default:
    // if (digits.startsWith("0") && digits.length >= 10) return `+212${digits.slice(1)}`;
    if (digits.length >= 6) return `+1${digits}`;
    return v;
  };

  const strongRandomPassword = () => {
    const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const lower = "abcdefghijklmnopqrstuvwxyz";
    const nums  = "0123456789";
    const spec  = "!@#$%^&*()-_=+[]{}";
    const all = upper + lower + nums + spec;
    const pick = (n, s) => Array.from({ length: n }, () => s[Math.floor(Math.random() * s.length)]).join("");
    return [pick(1, upper), pick(1, lower), pick(1, nums), pick(1, spec), pick(16, all)].join("");
  };

  const handlePhoneSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true); setError(""); setInfo("");

    const e164 = toE164(phoneNumber);

    try {
      if (!e164.startsWith("+")) {
        setError("Please enter a valid E.164 phone (e.g., +2126...)");
        setIsLoading(false);
        return;
      }

      // 🔑 Try passwordless sign-in (omit password entirely)
      await signIn({ username: e164, options: { authFlowType: 'USER_AUTH' } });

      // If session already exists (rare), we’re done; else Cognito sent an OTP
      const session = await fetchAuthSession();
      setIsLoading(false);
      if (session?.tokens) {
        onVerificationComplete(e164);
      } else {
        setMode(1); setStep("otp");
        setInfo("We sent you a sign-in code by SMS.");
      }
    } catch (err) {
      // Decide how to handle by error name
      const name = err?.name || err?.__type || "";

      if (name.includes("UserNotFound")) {
        // 👤 No user → create it (Cognito will send sign-up code)
        const password = strongRandomPassword();
        setTmpPwd(password);
        try {
          await signUp({
            username: e164,
            password,
            options: { userAttributes: { phone_number: e164 } },
          });
          setIsLoading(false);
          setMode(2); setStep("otp");
          setInfo("We sent you a verification code to create your account.");
        } catch (e2) {
          setIsLoading(false);
          setError(e2?.message || "Failed to send verification code.");
        }
      } else if (name.includes("UserNotConfirmed")) {
        // 📨 Existing but unconfirmed → send (or re-send) sign-up code
        try {
          await resendSignUpCode({ username: e164 });
          setIsLoading(false);
          setMode(2); setStep("otp");
          setInfo("Your account isn’t confirmed yet. We re-sent the verification code.");
        } catch (e3) {
          setIsLoading(false);
          setError(e3?.message || "Could not resend confirmation code.");
        }
      } else if (name.includes("PasswordResetRequired")) {
        setIsLoading(false);
        setError("Password reset required; please contact support.");
      } else if (name.includes("NotAuthorized")) {
        // This can happen if the flow is misaligned. Show a helpful hint.
        setIsLoading(false);
        setError("Sign-in failed. Make sure Phone OTP is enabled for this app client.");
      } else {
        setIsLoading(false);
        setError(err?.message || "Failed to start sign-in.");
      }
    }
  };

  const handleOtpSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true); setError(""); setInfo("");

    try {
      const e164 = toE164(phoneNumber);
      if (otpCode.length < 4) {
        setError("Enter the 6-digit code");
        setIsLoading(false); return;
      }

      if (mode === 1) {
        // ✅ confirm SIGN-IN code
        await confirmSignIn({ challengeResponse: otpCode });
        const session = await fetchAuthSession();
        setIsLoading(false);
        if (session?.tokens) onVerificationComplete(e164);
        else setError("Could not complete sign-in. Resend and try again.");
      } else if (mode === 2) {
        // ✅ confirm SIGN-UP code, then sign in once
        await confirmSignUp({ username: e164, confirmationCode: otpCode });
        try {
          await signIn({ username: e164, options: { authFlowType: 'USER_AUTH' } }); // no password; next time it will be OTP-only
          const session = await fetchAuthSession();
          setIsLoading(false);
          if (session?.tokens) onVerificationComplete(e164);
          else setError("Signed up. Tap Get code to sign in.");
        } catch {
          setIsLoading(false);
          setError("Account created. Tap Get code to sign in.");
        }
      } else {
        setIsLoading(false);
        setError("Request a code first.");
      }
    } catch (e4) {
      setIsLoading(false);
      setError(e4?.message || "Invalid/expired code.");
    }
  };

  const handleResend = async () => {
    setIsLoading(true); setError(""); setInfo("");
    const e164 = toE164(phoneNumber);
    try {
      if (mode === 1) {
        // Re-run signIn without password to resend sign-in OTP
        await signIn({ username: e164, options: { authFlowType: 'USER_AUTH' } });
        setInfo("Code re-sent.");
      } else if (mode === 2) {
        await resendSignUpCode({ username: e164 });
        setInfo("Verification code re-sent.");
      }
    } catch (e) {
      setError(e?.message || "Unable to resend code.");
    }
    setIsLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-md">
        <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-0">
          <CardHeader className="text-center pb-6">
            <div className="w-16 h-16 mx-auto mb-4 bg-[#E4E1F7] rounded-full flex items-center justify-center">
              <Shield className="w-8 h-8" style={{ color: "#20194B" }} />
            </div>
            <CardTitle className="text-2xl font-bold text-slate-900">
              {step === "phone" ? "Verify Your Phone" : "Enter Verification Code"}
            </CardTitle>
            <p className="text-slate-600 mt-2">
              {step === "phone"
                ? "Enter your phone number to sync your Fig Phone data securely"
                : `We sent a 6-digit code to ${phoneNumber}`}
            </p>
          </CardHeader>

          <CardContent>
            {step === "phone" ? (
              <form onSubmit={handlePhoneSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="phone" className="text-sm font-medium text-slate-700">Phone Number</Label>
                  <div className="relative mt-1">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                      <Smartphone className="h-5 w-5 text-slate-400" />
                    </div>
                    <Input
                      id="phone"
                      type="tel"
                      inputMode="tel"
                      placeholder="(e.g. +2126..., +1415...)"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(formatPhoneInput(e.target.value))}
                      className="pl-12 h-12 text-lg"
                      maxLength={18}
                      required
                      pattern="^\+?[0-9]{6,15}$"
                    />
                  </div>
                </div>

                {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-lg">{error}</p>}
                {info  && <p className="text-sm text-green-700 bg-green-50 p-3 rounded-lg">{info}</p>}

                <Button
                  type="submit"
                  className="w-full h-12"
                  style={{ backgroundColor: "#20194B" }}
                  disabled={isLoading}
                >
                  {isLoading ? "Sending Code..." : <>Send Verification Code <ArrowRight className="w-4 h-4 ml-2" /></>}
                </Button>

                <div className="flex items-center gap-2 text-xs text-slate-500 mt-4">
                  <Lock className="w-4 h-4" />
                  <span>Your phone number is encrypted and never shared</span>
                </div>
              </form>
            ) : (
              <form onSubmit={handleOtpSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="otp" className="text-sm font-medium text-slate-700">Verification Code</Label>
                  <Input
                    id="otp"
                    type="text"
                    placeholder="123456"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    className="text-center text-2xl font-mono tracking-widest h-12"
                    maxLength={6}
                    required
                  />
                </div>

                {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-lg">{error}</p>}
                {info  && <p className="text-sm text-green-700 bg-green-50 p-3 rounded-lg">{info}</p>}

                <Button
                  type="submit"
                  className="w-full h-12"
                  style={{ backgroundColor: "#20194B" }}
                  disabled={isLoading || otpCode.length !== 6}
                >
                  {isLoading ? "Verifying..." : mode === 1 ? "Verify & Sign in" : "Verify & Create account"}
                </Button>

                <div className="flex items-center justify-between">
                  <Button type="button" variant="ghost" className="mt-2" onClick={() => setStep("phone")} disabled={isLoading}>
                    ← Change Phone Number
                  </Button>
                  <Button type="button" variant="ghost" className="mt-2" onClick={handleResend} disabled={isLoading}>
                    Resend code
                  </Button>
                </div>
              </form>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
