import { Amplify } from 'aws-amplify';

Amplify.configure({
  Auth: {
    Cognito: {
      userPoolId: 'us-east-1_jjggDH8et',
      userPoolClientId: '7njknijkbtoog0nbn6n0h26de6',
      loginWith: { username: false, email: false, phone: true },
      signUpVerificationMethod: 'code',
    },
  },
});
