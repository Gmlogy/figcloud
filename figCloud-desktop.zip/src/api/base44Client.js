// import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// --- THIS ENTIRE BLOCK IS NOW DISABLED TO PREVENT REDIRECT ---
/*
export const base44 = createClient({
  appId: "688bdbfc12944a7f10b09795", 
  requiresAuth: true 
});
*/