// import { base44 } from './base44Client';


// export const Message = base44.entities.Message;

/* export const SyncSession = base44.entities.SyncSession;

export const Photo = base44.entities.Photo;

export const Contact = base44.entities.Contact;

export const ReverseSync = base44.entities.ReverseSync;

export const AllowedDevice = base44.entities.AllowedDevice;



// auth sdk:
export const User = base44.auth; */